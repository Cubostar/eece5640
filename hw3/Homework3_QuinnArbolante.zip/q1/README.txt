Compile my code with the following commands:

g++ sinx_sp.cpp -o sinx_sp
g++ sinx_dp.cpp -o sinx_dp

Run my code with the following commands:

./sinx_sp <x> <n_terms>
./sinx_dp <x> <n_terms>
