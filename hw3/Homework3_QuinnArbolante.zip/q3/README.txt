Compile my code with the following command:

gcc matmul.c -o matmul

Run my code with the following command:

./matmul
