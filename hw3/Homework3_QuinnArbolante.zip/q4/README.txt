Compile my code with the following command:

gcc blas_simple.c -lopenblas -o matmul

Run my code with the following command:

./blas_simple.c
