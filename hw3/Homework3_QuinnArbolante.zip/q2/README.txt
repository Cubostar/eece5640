Compile my code with the following command:

gcc matrix-vector-AVX.c -mavx512f -o matrix-vector-AVX

To get the assembly listing, use this command:

gcc matrix-vector-AVX.c -mavx512f -S matrix-vector-AVX

Run my code with the following command:

./matrix-vector-AVX
